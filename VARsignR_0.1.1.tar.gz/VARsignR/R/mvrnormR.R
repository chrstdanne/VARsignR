mvrnormR <-
function(n, mu, sigma){
  ncols <- ncol(sigma)
  mu <- rep(mu, each = n)
  mvndraw <- mu + matrix(rnorm(n * ncols), ncol = ncols) %*% chol(sigma)
  return(mvndraw)
}
